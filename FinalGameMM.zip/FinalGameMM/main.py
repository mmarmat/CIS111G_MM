import numpy as np
import random

debug = False
COLUMNS = 7
ROWS = 6
global difficulty
difficulty = 10
global gameselect
gameselect = 2



def newgame(dif = False):
    global board
    board = np.zeros((ROWS,COLUMNS))     
    menu = True
    if dif:
        while menu:
            gameselect = input("\nEnter the number of players (1 = Multiplayer, 2 = Singleplayer): ")
            while gameselect != "1" and gameselect != "2":
                gameselect = input("\nEnter the number of players (1 = Multiplayer, 2 = Singleplayer): ")
            gameselect = int(gameselect)


            confirm = input("\nYou selected '" + str(gameselect) + "' confirm? (Y or N): ")
            confirm = confirm.upper()
            while confirm != "Y" and confirm != "N":
                confirm = input("\nYou selected '" + gameselect + "' confirm? (Y or N): ")
                confirm = confirm.upper()
            if confirm == "N":
                continue
            if confirm == "Y":
                return gameselect
    else:
        return board            
        
    
    

def column_check(c = 0):
    i = 0
    Error = 0
    tempB = True
    for i in range(6):
        try:
            if board[i,c] != 0: 
                if i == 0:  
                    tempB = False
                    return 8  
                else:
                    i -= 1
                    tempB = False
                    return i  
        except IndexError:
            Error += 1
    return 5 


def turn_input(turn):
    move = 0
    temp = True
    while temp:
        try:
            move = int(input("\nP" + str(turn) + ": Choose what column to place the checker (1-7): "))
            if 1 <= move <= 7:
                move -= 1
                if column_check(move) == 8:
                    print("Column is full, please choose another. ")
                else:
                    return move
            else:
                print("Please input an integer between the designated values (1-7): ")   

        except ValueError:
            print("Invalid input. Please enter an integer.")

def move_check(c = 0, turn = 1):
    lrow = column_check(c)
    if turn == 1:
        board[(lrow), c] = 1
    else:
        board[(lrow), c] = 2

def tie_check():
    for c in range(0, COLUMNS - 1):
        if board[0, c] == 0:  
            return False
        else:
            continue    
    return True


def win_check(turn = 1):
    for r in range(ROWS):
        for c in range(COLUMNS - 3):  
            if board[r,c] == turn:
                if board[r,c] == board[r,c + 1] == board[r,c + 2] == board[r,c + 3]:
                    return True

    for c in range(COLUMNS):
        for r in range(ROWS - 3):
            if board[r,c] == turn:
                if board[r,c] == board[r + 1,c] == board[r + 2,c] == board[r + 3,c]:
                    return True

    for r in range(ROWS - 3):
        for c in range(COLUMNS - 3):
            if board[r,c] == turn:
                if board[r,c] == board[r + 1,c + 1] == board[r + 2,c + 2] == board[r + 3,c + 3]:
                    return True

    for r in range(ROWS - 3):
        for c in range(3, COLUMNS):
            if board[r,c] == turn:
                if board[r,c] == board[r + 1,c - 1] == board[r + 2,c - 2] == board[r + 3,c - 3]:
                    return True


    return False



def calc_weight(r = 0, c = 0, trigger = False, turn = 2):
    

    if r <= 2:
        vRng = 4
    else:
        vRng = (ROWS - 1) - r

    if c == 3:
        lRng = 4
        rRng = 4
    elif c < 3:
        lRng = c + 1
        rRng = 4
    elif c > 3:
        lRng = 4
        rRng = (COLUMNS - 1) - c
    
    
    tWeight = 0

    if debug:
        print("C = " + str(c + 1) + " | R = " + str(r + 1) + " | rRng = " + str(rRng) + " | lRng = " + str(lRng) + " | vRng = " + str(vRng))

    if r < 0 or r >= ROWS or c < 0 or c >= COLUMNS:
        return tWeight

    consec = 0
    global extra_hits
    extra_hits = 0
    for temp in range(1, rRng):  
        if board[r, c + temp] == turn:
            consec += 1
            if difficulty == 1:
                tWeight += 1    
            elif difficulty == 2:
                tWeight += 2
            elif difficulty == 3:
                tWeight += 3
            elif difficulty == 4:
                tWeight += 5
            elif difficulty >= 5:
                tWeight += 10
    if consec == 2:
        extra_hits += 5 * difficulty * consec
    elif consec == 3:
        extra_hits += 15 * difficulty * consec
            
    
    consec = 0
    for temp in range(1, lRng):  
        if c - temp >= 0:  
            if board[r, c - temp] == turn:  
                consec += 1
                if difficulty == 1:
                    tWeight += 1
                elif difficulty == 2:
                    tWeight += 2
                elif difficulty == 3:
                    tWeight += 3
                elif difficulty == 4:
                    extra_hits += 1
                    tWeight += 5
                elif difficulty >= 5:
                    extra_hits += 2
                    tWeight += 10
    if consec == 2:
        extra_hits += 5 * difficulty * consec
    elif consec == 3:
        extra_hits += 15 * difficulty * consec

    
    consec = 0
    if vRng == 1:
        vRng = 2   

    for temp in range(vRng):  
        if 0 <= r + temp < len(board) and 0 <= c < len(board[0]):  
            if board[r + temp, c] == turn:
                consec += 1
                if difficulty == 1:
                    tWeight += 1
                elif difficulty == 2:
                    tWeight += 2
                elif difficulty == 3:
                    tWeight += 3
                elif difficulty == 4:
                    extra_hits += 1
                    tWeight += 5
                elif difficulty >= 5:
                    extra_hits += 2
                    tWeight += 10
    if consec == 2:
        extra_hits += 5 * difficulty * consec
    elif consec == 3:
        extra_hits += 15 * difficulty * consec
    
    consec = 0
    for temp in range(1, vRng + 1):  
        if r + temp < ROWS and c - temp >= 0:  
            if board[r + temp, c - temp] == turn:  
                consec += 1
                if difficulty == 1:
                    tWeight += 1
                elif difficulty == 2:
                    tWeight += 2
                elif difficulty == 3:
                    tWeight += 3
                elif difficulty == 4:
                    extra_hits += 1
                    tWeight += 5
                elif difficulty >= 5:
                    extra_hits += 2
                    tWeight += 10
    if consec == 2:
        extra_hits += 5 * difficulty * consec
    elif consec == 3:
        extra_hits += 15 * difficulty * consec    

    consec = 0
    for temp in range(1, vRng + 1): 
        if r - temp >= 0 and c + temp < COLUMNS:  
            if board[r - temp, c + temp] == turn:  
                consec += 1
                if difficulty == 1:
                    tWeight += 1
                elif difficulty == 2:
                    tWeight += 2
                elif difficulty == 3:
                    tWeight += 3
                elif difficulty == 4:
                    extra_hits += 1
                    tWeight += 5
                elif difficulty >= 5:
                    extra_hits += 2
                    tWeight += 10
    if consec == 2:
        extra_hits += 5 * difficulty * consec
    elif consec == 3:
        extra_hits += 15 * difficulty * consec    

    consec = 0
    for temp in range(1, vRng + 1):  
        if r + temp < ROWS and c + temp < COLUMNS: 
            if board[r + temp, c + temp] == turn: 
                consec += 1
                if difficulty == 1:
                    tWeight += 1
                elif difficulty == 2:
                    tWeight += 2
                elif difficulty == 3:
                    tWeight += 3
                elif difficulty == 4:
                    extra_hits += 1
                    tWeight += 5
                elif difficulty >= 5:
                    extra_hits += 2
                    tWeight += 10
        
    if consec == 2:
        extra_hits += 5 * difficulty * consec
    elif consec == 3:
        extra_hits += 15 * difficulty * consec        

    consec = 0
    for temp in range(1, vRng + 1): 
        if r - temp >= 0 and c - temp >= 0: 
            if board[r - temp, c - temp] == turn: 
                consec += 1
                if difficulty == 1:
                    tWeight += 1
                elif difficulty == 2:
                    tWeight += 2
                elif difficulty == 3:
                    tWeight += 3
                elif difficulty == 4:
                    tWeight += 5
                elif difficulty >= 5:
                    tWeight += 10

    if consec == 2:
        extra_hits += 5 * difficulty * consec
    elif consec == 3:
        extra_hits += 15 * difficulty * consec    
            

    

    if trigger:
        return extra_hits
    else:
        return tWeight


def move_weight(turn):
    column_weights = [0] * COLUMNS

    c0r = column_check(0)
    c1r = column_check(1)
    c2r = column_check(2)
    c3r = column_check(3)
    c4r = column_check(4)
    c5r = column_check(5)
    c6r = column_check(6)
    column_places = [c0r,c1r,c2r,c3r,c4r,c5r,c6r]

    x = 0
    
    for x in range(len(column_places)):
        temp_weight = 0
        temp_weight += calc_weight(column_places[x], x)
        column_weights[x] = temp_weight
    
    tempc = -1
    visCol = 0
    
    while tempc < 6:
        tempc+=1
        visCol+=1
        if debug:
            print("Col: " + str(visCol) + "; W = " + str(calc_weight(column_check(tempc), tempc, True)) + " | ")
        
        column_weights[x] = (calc_weight(column_check(tempc), tempc) + calc_weight(column_check(tempc), tempc, True) + calc_weight(column_check(tempc), tempc, True, 1))
    
        

    
    return column_weights



def ai_turn():
    movelist = np.array([4])
    weights = move_weight(2)
    for x in range(6):
        for each in range(weights[x] + extra_hits):
            movelist = np.append(movelist, x)

    if len(movelist) > 1:
        movelist = np.delete(movelist, 0)
    aselect = random.randint(0,len(movelist))
    
    checker = True
    while checker:
        try:
            aselect = random.randint(0,len(movelist))
            if column_check(movelist[aselect]) == 8:
                aselect = random.randint(0,len(movelist))

            if column_check(movelist[aselect]) <= 5:
                checker = False
                print("Ai chose to place at: " + str((movelist[aselect]) + 1))
        except IndexError:
            print("Ai picked a bad one, retrying...")

    if debug:
        print(movelist)
        print(aselect)

    return movelist[aselect]

board = newgame()


gameselect = newgame(True)
while gameselect == 2:
    try:
        difficulty_input = input("\nEnter the difficulty of AI (recommended: 1-10 | Challenge (10-50)): ")
        difficulty = int(difficulty_input) 
        if 1 <= difficulty <= 50:
            break
        else:
            print("Please input an integer between 1 and 50.")

    except ValueError:
        print("Invalid input. Please enter an integer.") 


game_state = True
turn = 1
game_over = False
winner = 3
while game_state:
    if game_over:
        print(board)
        if winner == 0:
            print("The result was a tie!\n\n")
            
        else:
            print("The winner is player " + str(winner) + "! Congratulations for winning!\n\n")     

        menu = True
        while menu:
            playagain = input("Do you wish to play again? (Y or N): ")
            playagain = playagain.upper()
            while playagain != "Y" and playagain != "N":
                playagain = input("\n Do you wish to play again? (Y or N): ")
                playagain = playagain.upper()

            if playagain == "N":
                quit()
                
            if playagain == "Y":
                menu = False
                game_over = False
                game_state = True
                continue

        board = newgame()
    if gameselect == 1:
        print()
        print(board)
        print()
        if turn == 1:
            move = turn_input(1)
            move_check(move, 1)
            if win_check(1):
                winner = 1
                game_over = True
            elif tie_check():
                winner = 0
                game_over = True
            else:
                turn = 2
        elif turn == 2:
            move = turn_input(2)
            move_check(move, 2)
            if win_check(2):
                winner = 2
                game_over = True
            elif tie_check():
                winner = 0
                game_over = True
            else:
                turn = 1
    elif gameselect == 2:
        print()
        print(board)
        print()
        if turn == 1:
            move = turn_input(1)
            move_check(move, 1)
            if win_check(1):
                winner = 1
                game_over = True
            elif tie_check():
                winner = 0
                game_over = True
            else:
                turn = 2
                
        elif turn == 2:

            if debug:
                print(move_weight(2))

            move = ai_turn()
            move_check(move, 2)

            if debug:
                print(move_weight(2))

            if win_check(2):
                winner = 2
                game_over = True
            elif tie_check():
                winner = 0
                game_over = True
            else:
                turn = 1


    


        