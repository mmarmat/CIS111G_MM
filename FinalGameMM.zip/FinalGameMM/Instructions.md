Step 1: Open a new terminal and run the command: pip install numpy
This allows you to use the numpy module I use.

Summary:
This is a game of connect four, you can either play multiplayer with someone else or go against the AI, the AI isn't super refined, it essentially gives all the possible moves "weights" and will give the more optimal moves a higher chance of being picked by increasing the amount added to a list a random number generator takes from.

Instructions: 
Choose the gamemode by entering a 1 or 2, instructions are shown on there aswell.

Confirm your choice by using a Y or an N, case is not sensitive.

If you chose singleplayer you can choose the AI's strength (since the AI isn't very advanced even at 50 it isn't too hard to beat)

You simply chose which column to place the piece by entering a number using the keyboard and click enter when done.

The game will automatically calculate a tie, winner, and where to place the piece in a column.


Sources Used:
https://www.geeksforgeeks.org
https://www.w3schools.com
https://numpy.org
https://stackoverflow.com